package task2
fun findTheDefference(a:String,b:String):String{
    for (i in a){
        for (j in b){

        }
    }
    return "no contaning that string"
}
fun main() {
    val a="aybc"
    val b="ab"
    println(a.replace(b,""))
}
