package task3
fun main() {
    val pattern = "[a-zA-z0-9!@#$%^&*()-+]".toRegex()
    val str ="((((((((((499asldfbalkbfasdfbjkkdfaef349757834o7^%%#%$%&^#^%"
    println(pattern.containsMatchIn(str))


}
